/** @type {import('tailwindcss').Config} */
export default {
  content: ["./src/**/*.{astro,html,js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // NES Palette
        'nes-red': '#FF0000',
        'nes-yellow': '#FFFF00',
        'nes-blue': '#3B2A1A',
        'nes-black': '#000000',
        'nes-white': '#FFFFFF',
      }
    }
  },
  plugins: [],
  safelist: [
    // EXACT full classes — not patterns
    'data-[theme=matrix]:bg-green-400',
    'data-[theme=matrix]:text-black',
    'data-[theme=cyberpunk]:bg-amber-600',
    'data-[theme=cyberpunk]:text-pink-400',
    'data-[theme=nes]:bg-black',
    'data-[theme=nes]:text-yellow-200',
    'data-[theme=nes]:border-pink-500',
    'data-[theme=nes]:text-black',
    'data-[theme=nes]:bg-yellow-200'
  ]
}
